import pandas
import os

def get_site_city_dir():
    site_list_df = pandas.read_csv('site_list.csv',header=0, delimiter=',')
    code = site_list_df['监测点编码'].tolist()
    city = site_list_df['城市'].tolist()
    site_city_dir = dict(zip(code, city))
    return site_city_dir

def types():
    return ['AQI', 'PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']

def statistic_day(file_path):
    df = pandas.read_csv(file_path, header=0, delimiter=',').fillna(method='ffill')
    df = df.fillna(method='bfill')
    df = df.rename(columns={'3207A.1': '3207A'})
    # types = ['AQI', 'PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']
    type_index_dir = {'AQI': list(range(0, 360, 15)), 'PM2.5': list(range(1, 360, 15)),
     'PM10': list(range(3, 360, 15)), 'SO2': list(range(5, 360, 15)), 'NO2': list(range(7, 360, 15)),
     'O3':list(range(9, 360, 15)), 'CO':list(range(13, 360, 15))}
    type_mean_dir = {}
    for air_type in types():
        type_df_mean = df.ix[type_index_dir[air_type]].mean()
        type_df_mean = type_df_mean.drop(['date', 'hour'])
        type_mean_dir[air_type] = type_df_mean.values
        site_list = type_df_mean.index
    day_df = pandas.DataFrame(type_mean_dir, index=site_list).T
    day_df = day_df.rename(columns=get_site_city_dir())
    return day_df

def same_columns_mean(df):
    '''
    对dataframe中有相同列名的数据求平均
    '''
    city_list = list(df.columns)
    new_df = {}
    for city in city_list:
        city_df = df[[city]]
        city_mean = city_df.mean(axis=1).values
        new_df[city] = city_mean
    new_df = pandas.DataFrame(new_df, index=types())
    new_df = new_df.dropna(axis=1, how='all')
    return new_df

def output_city_day(data_dir):
    files = os.listdir(data_dir)
    for file_name in files:
        file_path = os.path.join(data_dir, file_names)
        df = statistic_day(file_path)
        df = same_columns_mean(df)
        day = file_name.replace('china_sites_', '')
        df.to_csv(os.path.join('city_day', day))
        print(day)
    return 0

    

if __name__ == "__main__":
    output_city_day('data')
