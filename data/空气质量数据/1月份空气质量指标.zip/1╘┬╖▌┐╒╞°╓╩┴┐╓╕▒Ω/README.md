
## 说明

- data : 网上下载到的原始数据：每个城市有多个站点，每个站点的24小时数据

- city_day(编码: utf-8) : 统计原始数据每天的平均值，之后对每个城市的多个站点再求平均值，请用utf-8编码格式的文本编辑器打开

- city_day_xls(编码: GB2312) : city_day 各个文件编码转为excel默认编码格式， 请用EXCEL打开

- province_day(编码: utf-8) : 对每个省份的各个城市求平均值，请用utf-8编码格式的文本编辑器打开

- province_day_xls(编码: GB2312) : province_day 各个文件编码转为excel默认编码格式，请用EXCEL打开


## TODO

- [x] 根据城市名称，获得各个省份每天的数据

- [ ] 获得上个月的平均数据